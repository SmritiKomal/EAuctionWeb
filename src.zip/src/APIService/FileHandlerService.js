import {storage} from '../firebaseInitialise';

var storageRef = storage.ref();
var itemWatchRef= storageRef.child('items/watch');

/*
export async function getImageURL(fileName){
    var fileWatchRef=itemWatchRef.child(fileName);
    var urlImage=await fileWatchRef.getDownloadURL();
    return urlImage;
}

export async function uploadFile(file){
    const uploadTask = itemWatchRef.child(`${file.name}`).put(file);
    uploadTask.on(
      "state_changed",
      snapshot => {
        const progress = Math.round(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        setProgress(progress);
      },
      error => {
        console.log(error);
      },
      () => {
        itemWatchRef.child(`${file.name}`)
          .getDownloadURL();
          .then(url => {
            setUrl(url);
          });
      }
    );
}*/
