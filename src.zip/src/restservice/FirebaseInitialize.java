package com.example.restservice;

import java.io.FileInputStream;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;
import com.google.auth.oauth2.GoogleCredentials;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.FirebaseOptions.Builder;

//let's spring boot know this is a service class and needs to be bound
@Service
public class FirebaseInitialize {
   //function initialize() should run before the start of the app
    @PostConstruct
    public void initialize() {
        try {
        FileInputStream serviceAccount =
                  new FileInputStream("C:/Users/USER/Downloads/auctionUser/src/main/java/com/example/resources/serviceKey.json");

                  FirebaseOptions options = FirebaseOptions.builder()
                  .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                  .setDatabaseUrl("https://eauctionms-default-rtdb.firebaseio.com")
                  .build();
                
                FirebaseApp.initializeApp(options);
    } catch (Exception e) {
        e.printStackTrace();
    }

}
}