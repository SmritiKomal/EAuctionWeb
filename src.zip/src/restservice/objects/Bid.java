package com.example.restservice.objects;

public class Bid {
    public static String bidResultPossibility[]={"SUCCESSFUL", "FAILED", "ONGOING"};
    String bidID;
    String userID;
    String itemID;
    double bidPrice;
    long timestamp;
    String bidResult;

   

    public Bid(){

    }

    public Bid(String bidID, String userID, String itemID, double bidPrice, long timestamp) {
        this.bidID = bidID;
        this.userID = userID;
        this.itemID = itemID;
        this.bidPrice = bidPrice;
        this.timestamp = timestamp;
        this.bidResult=bidResultPossibility[2];
    }
    
    public String getBidResult() {
        return bidResult;
    }

    public void setBidResult(String bidResult) {
        this.bidResult = bidResult;
    }

    public String getBidID() {
        return bidID;
    }

    public void setBidID(String bidID) {
        this.bidID = bidID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public double getBidPrice() {
        return bidPrice;
    }

    public void setBidPrice(double bidPrice) {
        this.bidPrice = bidPrice;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    

}
