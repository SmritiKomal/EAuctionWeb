package com.example.restservice.objects;

public class Login 
{
public String email;
public String password;
public String userType;
public Login(){
};

public Login(String email, String password, String userType){
    this.email=email;
    this.password=password;
    this.userType=userType;
}

public String getEmail(){
    return this.email;
}

public String getPassword(){
    return this.password;
}

public String getUserType(){
    return this.userType;
}
}
