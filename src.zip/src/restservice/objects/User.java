package com.example.restservice.objects;

public class User {
private String userType;
private int age;
private String email;
private String mobile;
private String name;
private String pan;
private String password;
private String presentAddress;
private String userID;
private String aadhar;
private String gender;

public User(){
};

public User( String aadhar,int age, String email, String gender, String mobile, String name, String pan, String password, String presentAddress, String userID, String userType){
    this.aadhar=aadhar;
    this.age=age;
    this.email=email;
    this.gender=gender;
    this.mobile=mobile;
    this.name=name;
    this.pan=pan;
    this.password=password;
    this.presentAddress=presentAddress;
    this.userID=userID;
    this.userType=userType;
}

public int getAge(){
    return this.age;
}

public String getEmail(){
    return this.email;
}

public String getMobile(){
    return this.mobile;
}

public String getName(){
    return this.name;
}

public String getPan(){
    return this.pan;
}

public String getPassword(){
    return this.password;
}

public String getPresentAddress(){
    return this.presentAddress;
}

public String getUserID(){
    return this.userID;
}

public String getAadhar(){
    return this.aadhar;
}

public String getGender(){
    return this.gender;
}

public String getUserType(){
    return this.userType;
}
}
