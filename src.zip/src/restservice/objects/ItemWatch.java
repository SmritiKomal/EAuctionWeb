package com.example.restservice.objects;

public class ItemWatch extends Item {
    private String source;
    private double weight;
    private String brandName;

    @Override
    public int hashCode() {

        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((brandName == null) ? 0 : brandName.hashCode());
        long temp;
        temp = Double.doubleToLongBits(itemAge);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((source == null) ? 0 : source.hashCode());
        temp = Double.doubleToLongBits(weight);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + (workingCondition ? 1231 : 1237);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            ItemWatch other = (ItemWatch) obj;
            if (brandName == null) {
                if (other.brandName != null)
                    return false;
            } else if (!brandName.equals(other.brandName))
                return false;
            if (Double.doubleToLongBits(itemAge) != Double.doubleToLongBits(other.itemAge))
                return false;
            if (source == null) {
                if (other.source != null)
                    return false;
            } else if (!source.equals(other.source))
                return false;
            if (Double.doubleToLongBits(weight) != Double.doubleToLongBits(other.weight))
                return false;
            if (workingCondition != other.workingCondition)
                return false;
            return true;
        } else
            return false;

    }

    private double itemAge;
    private boolean workingCondition;

    public ItemWatch() {
        super();
    }

    public ItemWatch(String itemID, String itemName, String itemType, String vendorID, double basePrice,
            String imageURL, String source, double weight, String brandName, double itemAge, boolean workingCondition,
            long startingDateTime, long endingDateTime) {
        super(itemID, itemName, itemType, vendorID, basePrice, imageURL, startingDateTime, endingDateTime);
        this.source = source;
        this.weight = weight;
        this.brandName = brandName;
        this.itemAge = itemAge;
        this.workingCondition = workingCondition;
    }

    public String getSource() {
        return this.source;
    }

    public double getWeight() {
        return this.weight;
    }

    public String getBrandName() {
        return this.brandName;
    }

    public double getItemAge() {
        return this.itemAge;
    }

    public boolean getWorkingCondition() {
        return this.workingCondition;
    }
}
