package com.example.restservice.objects;



public class Item {
private String itemID;
private String itemName;
private String itemType;
private String vendorID;
private double basePrice;
private double currentBidPrice;
private String currentBidderID;
private double finalPrice;
private String imageURL;
private long startingDateTime;
private long endingDateTime;
private String auctionStatus;
private String transactionStatus;

public static String auctionStatusPossibility[]={"upcoming", "ongoing", "end"};
public static String transactionStatusPossibility[]={"successful", "failed", "upcoming"};

public Item(){
    
}

public Item(String itemID,String itemName, String itemType, String vendorID, double basePrice,String imageURL, long startingDateTime, long endingDateTime ){
    this.itemID=itemID;
    this.itemName=itemName;
    this.itemType=itemType;
    this.vendorID=vendorID;
    this.basePrice=basePrice;
    this.currentBidPrice=basePrice;
    this.currentBidderID="";
    this.finalPrice=0.0;
    this.imageURL=imageURL;
    this.startingDateTime=startingDateTime;
    this.endingDateTime=endingDateTime;
}

public String getTransactionStatus(){
    return this.transactionStatus;
}

public void setTransactionStatus(String transactionStatus){
    this.transactionStatus=transactionStatus;
}

public String getAuctionStatus(){
    return this.auctionStatus;
}

public void setAuctionStatus(String auctionStatus){
    this.auctionStatus=auctionStatus;
}

public String getItemID(){
    return this.itemID;
}
public String getItemName(){
    return this.itemName;
}
public String getItemType(){
    return this.itemType;
}
public String getVendorID(){
    return this.vendorID;
}
public double getBasePrice(){
    return this.basePrice;
}

public double getCurrentBidPrice(){
    return this.currentBidPrice;
}
public String getCurrentBidderID(){
    return this.currentBidderID;
}
public double getFinalPrice(){
    return this.finalPrice;
}

public String getImageURL(){
    return this.imageURL;
}

public long getStartingDateTime(){
    return this.startingDateTime;
}
@Override
public int hashCode() {
    final int prime = 31;
    int result = 1;
    long temp;
    temp = Double.doubleToLongBits(basePrice);
    result = prime * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(currentBidPrice);
    result = prime * result + (int) (temp ^ (temp >>> 32));
    result = prime * result + ((currentBidderID == null) ? 0 : currentBidderID.hashCode());
    result = prime * result + (int) (endingDateTime ^ (endingDateTime >>> 32));
    temp = Double.doubleToLongBits(finalPrice);
    result = prime * result + (int) (temp ^ (temp >>> 32));
    result = prime * result + ((imageURL == null) ? 0 : imageURL.hashCode());
    result = prime * result + ((itemID == null) ? 0 : itemID.hashCode());
    result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
    result = prime * result + ((itemType == null) ? 0 : itemType.hashCode());
    result = prime * result + (int) (startingDateTime ^ (startingDateTime >>> 32));
    result = prime * result + ((vendorID == null) ? 0 : vendorID.hashCode());
    return result;
}

@Override
public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    Item other = (Item) obj;
    if (Double.doubleToLongBits(basePrice) != Double.doubleToLongBits(other.basePrice))
        return false;
    if (Double.doubleToLongBits(currentBidPrice) != Double.doubleToLongBits(other.currentBidPrice))
        return false;
    if (currentBidderID == null) {
        if (other.currentBidderID != null)
            return false;
    } else if (!currentBidderID.equals(other.currentBidderID))
        return false;
    if (endingDateTime != other.endingDateTime)
        return false;
    if (Double.doubleToLongBits(finalPrice) != Double.doubleToLongBits(other.finalPrice))
        return false;
    if (imageURL == null) {
        if (other.imageURL != null)
            return false;
    } else if (!imageURL.equals(other.imageURL))
        return false;
    if (itemID == null) {
        if (other.itemID != null)
            return false;
    } else if (!itemID.equals(other.itemID))
        return false;
    if (itemName == null) {
        if (other.itemName != null)
            return false;
    } else if (!itemName.equals(other.itemName))
        return false;
    if (itemType == null) {
        if (other.itemType != null)
            return false;
    } else if (!itemType.equals(other.itemType))
        return false;
    if (startingDateTime != other.startingDateTime)
        return false;
    if (vendorID == null) {
        if (other.vendorID != null)
            return false;
    } else if (!vendorID.equals(other.vendorID))
        return false;
    return true;
}

public long getEndingDateTime(){
    return this.endingDateTime;
}

public void setImageURL(String itemImageURL){
    this.imageURL=itemImageURL;
}
public void setCurrentBidPrice(double currentBidPrice){
    this.currentBidPrice=currentBidPrice;
}
public void setCurrentBidderID(String currentBidderID){
    this.currentBidderID=currentBidderID;
}
public void setFinalPrice(double finalPrice){
    this.finalPrice=finalPrice;
}
}
