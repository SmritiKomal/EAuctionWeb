package com.example.restservice.objects;

public class Forgot {
public String userType;
public String email;
public String mobile;
public String name;
public String pan;
public String age;
public String password;
public String presentAddress;
public String userID;
public String aadhar;
public String gender;

public Forgot(){
};

public Forgot( String aadhar, String email, String gender, String mobile, String name, String pan, String password, String presentAddress, String userID, String userType){
    this.aadhar=aadhar;
   
    this.email=email;
    this.gender=gender;
    this.mobile=mobile;
    this.name=name;
    this.pan=pan;
    this.password=password;
    this.presentAddress=presentAddress;
    this.userID=userID;
    this.userType=userType;
}


public void setEmail(String email){
    this.email=email;
}

public void setMobile(String mobile){
    this.mobile=mobile;
}

public void setName(String name){
    this.name=name;
}

public void setPan(String pan){
    this.pan=pan;
}

public void setPassword(String password){
    this.password=password;
}

public void setPresentAddress(String presentAddress){
    this.presentAddress=presentAddress;
}

public void setUserID(String userID){
    this.userID=userID;
}

public void setAadhar(String aadhar){
    this.aadhar=aadhar;
}

public void setGender(String gender){
    this.gender=gender;
}

public void setUserType(String userType){
    this.userType=userType;
}


public String getEmail(){
    return this.email;
}

public String getMobile(){
    return this.mobile;
}

public String getName(){
    return this.name;
}

public String getPan(){
    return this.pan;
}

public String getPassword(){
    return this.password;
}

public String getPresentAddress(){
    return this.presentAddress;
}

public String getUserID(){
    return this.userID;
}

public String getAadhar(){
    return this.aadhar;
}

public String getGender(){
    return this.gender;
}

public String getUserType(){
    return this.userType;
}
}
