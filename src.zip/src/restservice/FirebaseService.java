package com.example.restservice;

import java.util.concurrent.ExecutionException;
import java.io.IOException;
import java.nio.file.Paths;
import java.io.FileInputStream;
import java.util.UUID;

import com.example.restservice.objects.Forgot;
import com.example.restservice.objects.Login;
import com.example.restservice.objects.User;
import com.example.restservice.objects.Bid;
import com.example.restservice.objects.Item;
import com.example.restservice.objects.ItemWatch;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.cloud.FirestoreClient;

import java.util.*;

import com.google.firebase.FirebaseOptions;
import org.springframework.stereotype.Service;

@Service
public class FirebaseService {
   
    public static final String collectionName="items";
    public static final String watch="watch";
    
    public String postUserDetails(User user)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        ApiFuture<WriteResult> collectionsApiFuture = dbFirestore.collection(user.getUserType()).document(user.getEmail()).set(user);
        return collectionsApiFuture.get().getUpdateTime().toString();
    }

    public Login getLoginDetails(String email, String userType, String password) throws InterruptedException, ExecutionException {
       
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(userType).document(email);
        ApiFuture<DocumentSnapshot> future = documentReference.get();

        DocumentSnapshot document = future.get();

        Login user = null;

        if(document.exists()) {
            user = document.toObject(Login.class);
            if(user.password.equals(password))
            return user;
            else
            return null;
        }else {
            return null;
        }
}

 public String getValidationDetails(String email, String userType, String aadhar,String password) throws InterruptedException, ExecutionException {
       
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(userType).document(email);
        ApiFuture<DocumentSnapshot> future = documentReference.get();

        DocumentSnapshot document = future.get();

        Forgot user = null;

        if(document.exists()) {
         
        user = document.toObject(Forgot.class);
        
        if(user.aadhar.equals(aadhar))
            {
            ApiFuture<WriteResult> future3 = dbFirestore.collection(userType).document(email).update("password", password);
            future3.get().getUpdateTime().toString();
            return email;
            }
            else
               return "invalid"; 
        }
        else {
              return "not-found";
        }
}

 public String getUpdateDetails(String email, String userType, String mobile,String address) throws InterruptedException, ExecutionException {
       
        Firestore dbFirestore = FirestoreClient.getFirestore();
         
 
            ApiFuture<WriteResult> future1 = dbFirestore.collection(userType).document(email).update("mobile", mobile);
            future1.get().getUpdateTime().toString();
            
            ApiFuture<WriteResult> future2 = dbFirestore.collection(userType).document(email).update("presentAddress", address);
            future2.get().getUpdateTime().toString();
            
            return mobile+" "+address; 
}

 public String postItemDetails(ItemWatch itemWatch)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference=dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemWatch.getItemID());
        ApiFuture<WriteResult> collectionsApiFuture = documentReference.set(itemWatch);
        return collectionsApiFuture.get().getUpdateTime().toString();
    }

    public ItemWatch getWatchDetails(String itemID)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemID);
        ApiFuture<DocumentSnapshot> future = documentReference.get();
        DocumentSnapshot document = future.get();
        ItemWatch itemWatch = null;

        if(document.exists()) {
            itemWatch = document.toObject(ItemWatch.class);
            return itemWatch;
        }else {
            return null;
        }
    }

 
    
     //   ItemList API
    
        
    public List<ItemWatch> getItemList(String auctionType)throws InterruptedException, ExecutionException{
        Firestore db = FirestoreClient.getFirestore();
        
        System.out.println("auctionType :"+auctionType);

        ApiFuture<QuerySnapshot> futureItemsWithEndingDateTimeAfterToday = db.collection(collectionName).document(watch).collection(watch).whereGreaterThan("endingDateTime", System.currentTimeMillis()).get();
        List<QueryDocumentSnapshot> documentsEndingDateTimeAfterToday = futureItemsWithEndingDateTimeAfterToday.get().getDocuments();  
        
        if(auctionType.equals("ongoingAuction")){
            ApiFuture<QuerySnapshot> futureItemsWithStartingDateTimeBeforeToday = db.collection(collectionName).document(watch).collection(watch).whereLessThan("startingDateTime", System.currentTimeMillis()).get();
            List<QueryDocumentSnapshot> documentsStartingDateTimeBeforeToday = futureItemsWithStartingDateTimeBeforeToday.get().getDocuments();
            return getIntersectionListFromDocuments(documentsStartingDateTimeBeforeToday,documentsEndingDateTimeAfterToday);
        }
        else if(auctionType.equals("upcomingAuction")){
            ApiFuture<QuerySnapshot> futureItemsWithStartingDateTimeAfterToday = db.collection(collectionName).document(watch).collection(watch).whereGreaterThan("startingDateTime", System.currentTimeMillis()).get();
            List<QueryDocumentSnapshot> documentsStartingDateTimeAfterToday = futureItemsWithStartingDateTimeAfterToday.get().getDocuments();
            return getIntersectionListFromDocuments(documentsStartingDateTimeAfterToday,documentsEndingDateTimeAfterToday);
        }
        else{
            return  new ArrayList<ItemWatch>();
        }
    }


   
     //  BidDetails API
     

    public Bid getBidDetails(String bidID)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection("bid").document(bidID);
        ApiFuture<DocumentSnapshot> future = documentReference.get();
        DocumentSnapshot document = future.get();
        Bid bid = null;

        if(document.exists()) {
            bid = document.toObject(Bid.class);
            return bid;
        }else {
            return null;
        }
    }
    public String postBidDetails(Bid bid)throws InterruptedException, ExecutionException{
        
        //    1. Create an entry in document Bid with details
          //  2. Update ItemWatch document with new price if highest.

        
        String postBidDetailsInDBResult= postBidDetailsInDatabase(bid);
        String updateItemDetailsCurrentBidPriceResult= updateItemDetailsCurrentBidPrice(bid);
        
        
        return postBidDetailsInDBResult+"_"+updateItemDetailsCurrentBidPriceResult;
    }


    
     //  History API
     

    public Map<String,List<ItemWatch>> getVendorHistory(String vendorID)throws InterruptedException, ExecutionException {
        Firestore db = FirestoreClient.getFirestore();
        
        System.out.println("vendorID :"+vendorID);

        ApiFuture<QuerySnapshot> itemsForVendor = db.collection(collectionName).document(watch).collection(watch).whereEqualTo("vendorID", vendorID).get();
        List<QueryDocumentSnapshot> documentsForVendor = itemsForVendor.get().getDocuments();  
        
        List<ItemWatch> itemListForVendor=new ArrayList<>();
        for (DocumentSnapshot document : documentsForVendor) {
            System.out.println(document.getId() + " => " + document.toObject(ItemWatch.class));
            itemListForVendor.add(document.toObject(ItemWatch.class));    
        }
        return getAuctionStatusForItemListForVendor(itemListForVendor);

    }

    public  List<Map<String,Object>> getCustomerHistory(String userID)throws InterruptedException,ExecutionException {
        Firestore db = FirestoreClient.getFirestore();
        
        System.out.println("userID :"+userID);

        ApiFuture<QuerySnapshot> future = db.collection("bid").whereEqualTo("userID", userID).get();
        List<QueryDocumentSnapshot> documents = future.get().getDocuments();  
       
        List<Bid> bidList=new ArrayList<>();
        for (DocumentSnapshot document : documents) {
            System.out.println(document.getId() + " => " + document.toObject(Bid.class));
            bidList.add(document.toObject(Bid.class));    
        }

        List<Map<String,Object>> bidItemMapList=new ArrayList<Map<String,Object>>();
        for(Bid bid : bidList){
            Map<String,Object> propertyList = new HashMap<>();
            ItemWatch itemWatch=getWatchDetails(bid.getItemID());
            propertyList.put("bidResult", bid.getBidResult());
            propertyList.put("bidPrice", bid.getBidPrice());
            propertyList.put("itemName", itemWatch.getItemName());
            propertyList.put("itemType", itemWatch.getItemType());
            propertyList.put("basePrice", itemWatch.getBasePrice());
            propertyList.put("imageURL", itemWatch.getImageURL());
            propertyList.put("startingDateTime", itemWatch.getStartingDateTime());
            propertyList.put("endingDateTime", itemWatch.getEndingDateTime());


            if((bid.getBidResult().equals(Bid.bidResultPossibility[2]))){
                System.out.println("Ongoing Auction");
            }
            else if((bid.getBidResult().equals(Bid.bidResultPossibility[0]))){
                System.out.println("Successful Bid");
                propertyList.put("vendorID", itemWatch.getVendorID());
            }
            else if((bid.getBidResult().equals(Bid.bidResultPossibility[1]))){
                System.out.println("Failed Bid");
                propertyList.put("finalPrice", itemWatch.getFinalPrice());
            }


            bidItemMapList.add(propertyList);

        }

        return bidItemMapList;
    }
    

    
     //   API Helper Functions
    

    public Map<String,List<ItemWatch>> getAuctionStatusForItemListForVendor(List<ItemWatch> itemList) throws InterruptedException, ExecutionException{
        List<ItemWatch> ongoingAuctionItemList=new ArrayList<>();
        List<ItemWatch> upcomingAuctionItemList=new ArrayList<>();
        List<ItemWatch> endAuctionItemList=new ArrayList<>();
        HashMap<String,String> dbUpdateResults=new HashMap<>();
        Map<String, List<ItemWatch>> auctionStatusItemMap= new HashMap<>();
        
        for(ItemWatch itemWatch : itemList){
            if(itemWatch.getStartingDateTime() <= System.currentTimeMillis() && itemWatch.getEndingDateTime() > System.currentTimeMillis()){
                itemWatch.setAuctionStatus(Item.auctionStatusPossibility[1]);
                ongoingAuctionItemList.add(itemWatch);
            }
            else if(itemWatch.getEndingDateTime() <= System.currentTimeMillis()){
                itemWatch.setAuctionStatus(Item.auctionStatusPossibility[2]);
                endAuctionItemList.add(itemWatch);

                
                 // Make changes to the respective item's bid Details in the Bid table.
                 
                updateBidDetailsForEndAuction(itemWatch);
            }
            else if(itemWatch.getStartingDateTime() > System.currentTimeMillis() && itemWatch.getEndingDateTime() > System.currentTimeMillis()){
                upcomingAuctionItemList.add(itemWatch);
            }
            dbUpdateResults.put(itemWatch.getItemID(), postItemDetails(itemWatch));
        }

        auctionStatusItemMap.put(Item.auctionStatusPossibility[0], upcomingAuctionItemList);
        auctionStatusItemMap.put(Item.auctionStatusPossibility[1], ongoingAuctionItemList);
        auctionStatusItemMap.put(Item.auctionStatusPossibility[2], endAuctionItemList);

        return auctionStatusItemMap;
    }

    public void updateBidDetailsForEndAuction(ItemWatch itemWatch)throws InterruptedException, ExecutionException{
        List<Bid> bidDetailsList = getBidDetailsList(itemWatch.getItemID());
        double basePrice = itemWatch.getBasePrice();
        double finalItemPrice = itemWatch.getCurrentBidPrice();
        String finalItemPriceBidder = itemWatch.getCurrentBidderID();
        
        //checking whether there was atleast one bid on this item.
        if(finalItemPriceBidder!= null && finalItemPriceBidder.length()!=0 ){

            for(Bid bid : bidDetailsList){
                if((bid.getUserID()).equals(finalItemPriceBidder)){
                    System.out.println(bid.getUserID() + " has won the auction for itemID "+ itemWatch.getItemID());
                    bid.setBidResult(Bid.bidResultPossibility[0]);
                }
                else{
                    //bid failed
                    bid.setBidResult(Bid.bidResultPossibility[1]);
                }
                //update bid details in DB
                Firestore dbFirestore = FirestoreClient.getFirestore();
                ApiFuture<WriteResult> future = dbFirestore.collection("bid").document(bid.getBidID()).update("bidResult", bid.getBidResult());
                System.out.println(bid.getItemID() + " updated with "+ bid.getBidResult()+ ":"+ future.get().getUpdateTime().toString());
                itemWatch.setTransactionStatus(Item.transactionStatusPossibility[0]);
            }
        }
        else{
            //the auction failed, no one bid for the item.
            itemWatch.setTransactionStatus(Item.transactionStatusPossibility[1]);
        }
        
         //update item details in DB
         Firestore dbFirestore = FirestoreClient.getFirestore();
         ApiFuture<WriteResult> future = dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemWatch.getItemID()).update("transactionStatus", itemWatch.getTransactionStatus());
         System.out.println(itemWatch.getItemID() + " updated with "+ itemWatch.getTransactionStatus()+ ":"+ future.get().getUpdateTime().toString());
        
        
    }

    public List<Bid> getBidDetailsList(String itemID)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        ApiFuture<QuerySnapshot> futureBidDetails = dbFirestore.collection("bid").whereEqualTo("itemID",itemID).get();
        List<QueryDocumentSnapshot> documentsBidDetails = futureBidDetails.get().getDocuments();  

        List<Bid> bidList=new ArrayList<>();
        for (DocumentSnapshot document : documentsBidDetails) {
            System.out.println(document.getId() + " => " + document.toObject(Bid.class));
            bidList.add(document.toObject(Bid.class));
            }
    
        return bidList;
        
    }

    public List<ItemWatch> getIntersectionListFromDocuments(List<QueryDocumentSnapshot> documentA, List<QueryDocumentSnapshot> documentB){
            List<ItemWatch> itemListA=getItemListFromDocument(documentA);
            System.out.println(" startingDate beforeToday/ afterToday "+ itemListA);
            List<ItemWatch> itemListB=getItemListFromDocument(documentB);
            System.out.println(" endingDate AfterToday "+ itemListB);

            return getIntersectionList(itemListA, itemListB);
    }

    public List<ItemWatch> getItemListFromDocument(List<QueryDocumentSnapshot> documents){
        List<ItemWatch> itemList=new ArrayList<>();
        for (DocumentSnapshot document : documents) {
            System.out.println(document.getId() + " => " + document.toObject(ItemWatch.class));
                itemList.add(document.toObject(ItemWatch.class));
            }
    
            return itemList;
    }

    public List<ItemWatch> getIntersectionList(List<ItemWatch> listA, List<ItemWatch> listB){
        HashSet<ItemWatch> hashSetA = new HashSet<>();
        hashSetA.addAll(listA);
        List<ItemWatch> intersectionItemList=new ArrayList<>();

        for(ItemWatch item: listB){
            if(hashSetA.contains(item)){
                intersectionItemList.add(item);
            }
        }
        return intersectionItemList;
    }
    

    public String postBidDetailsInDatabase(Bid bid)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference=dbFirestore.collection("bid").document(bid.getBidID());
        ApiFuture<WriteResult> collectionsApiFuture = documentReference.set(bid);
        return collectionsApiFuture.get().getUpdateTime().toString();
    }


    public String updateItemDetailsCurrentBidPrice(Bid bid)throws InterruptedException, ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection(collectionName).document(watch).collection(watch).document(bid.getItemID());
        ApiFuture<DocumentSnapshot> future = documentReference.get();
        DocumentSnapshot document = future.get();
        ItemWatch itemWatch = null;

        if(document.exists()) {
            itemWatch = document.toObject(ItemWatch.class);
            double currentBidPrice=itemWatch.getCurrentBidPrice();
            if(currentBidPrice < bid.getBidPrice()){
                itemWatch.setCurrentBidPrice(bid.getBidPrice());
                itemWatch.setCurrentBidderID(bid.getUserID());
                ApiFuture<WriteResult> future2 = dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemWatch.getItemID()).update("currentBidPrice", bid.getBidPrice());
                ApiFuture<WriteResult> future3 = dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemWatch.getItemID()).update("currentBidderID", bid.getUserID());
                return future3.get().getUpdateTime().toString()+"::"+future2.get().getUpdateTime().toString();
            }
            else{
                return "Bid price Not greater";
            }
        
        }else {
            return null;
        }
    }

    
    //   Cleaning API not being implemented currently
    //  When the item has to be added to PreviousItems, post first and then delete in the frontend 
     
    public String postItemDetails(String subCollectionName,ItemWatch itemWatch)throws InterruptedException,ExecutionException{
            Firestore dbFirestore = FirestoreClient.getFirestore();
            //Collection items has a document named oldItems which has a collection named oldItems which has all the old items
            DocumentReference documentReference=dbFirestore.collection(collectionName).document(subCollectionName).collection(subCollectionName).document(watch).collection(watch).document(itemWatch.getItemID());
            ApiFuture<WriteResult> collectionsApiFuture = documentReference.set(itemWatch);
            return collectionsApiFuture.get().getUpdateTime().toString();
    }

    public String deleteItemDetails(String itemType,String itemID)throws InterruptedException,ExecutionException{
        Firestore dbFirestore = FirestoreClient.getFirestore();
        
        switch(itemType){
            case watch : DocumentReference documentReference = dbFirestore.collection(collectionName).document(watch).collection(watch).document(itemID);
                         ApiFuture<WriteResult> collectionsApiFuture= documentReference.delete();
                         return collectionsApiFuture.get().getUpdateTime().toString();
            default : return null;
    
        }
        
    }
    
}