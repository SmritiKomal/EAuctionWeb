package com.example.restservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.logging.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.restservice.objects.Bid;
import com.example.restservice.objects.Item;
import com.example.restservice.objects.ItemWatch;
import com.example.restservice.objects.Forgot;
import com.example.restservice.objects.User;
import com.example.restservice.objects.Login;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.HttpStatus;
import com.google.cloud.firestore.QueryDocumentSnapshot;

@RestController
public class UserController {


	@Autowired
    FirebaseService firebaseService;
	private final static Logger logger = 
                Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/user/postUserDetails")
	public String postUserDetails(@RequestBody User user)throws InterruptedException, ExecutionException{
		//@RequestBody annotation maps the HttpRequest body to an object with Jackson
		logger.log(Level.INFO, String.format("HIT getUserDetails aadhar %s age %d email %s gender %s mobile %s name %s pan %s password %s presentAddress %s userID %s",user.getAadhar(),user.getAge(),user.getEmail(),user.getGender(),user.getMobile(),user.getName(),user.getPan(),user.getPassword(),user.getPresentAddress(),user.getUserID()));
		return firebaseService.postUserDetails(user);

	}

	@CrossOrigin(origins = "http://localhost:3000/log")
	@GetMapping("/user/{userType}/getLoginDetails/{email}/{password}")
	public Login getLoginDetails(@PathVariable String email,@PathVariable String userType,@PathVariable String password)throws InterruptedException, ExecutionException {
                logger.log(Level.INFO, String.format("HIT getLoginDetails email %s userType %s password %s",email,userType,password));
		return firebaseService.getLoginDetails(email,userType,password);
	}


	@CrossOrigin(origins = "http://localhost:3000/res")
	@GetMapping("/user/{userType}/getValidationDetails/{email}/{aadhar}/{password}")
	public String getValidationDetails(@PathVariable String email,@PathVariable String userType,@PathVariable String aadhar,@PathVariable String password)throws InterruptedException, ExecutionException {
	logger.log(Level.INFO, String.format("HIT getValidationDetails password %s",password));

		return firebaseService.getValidationDetails(email,userType,aadhar,password);
	}
 
     	@CrossOrigin(origins = "http://localhost:3000/edit")
	@GetMapping("/user/{userType}/getUpdateDetails/{email}/{mobile}/{address}")
	public String getUpdateDetails(@PathVariable String email,@PathVariable String userType,@PathVariable String mobile,@PathVariable String address)throws InterruptedException, ExecutionException {
	logger.log(Level.INFO, String.format("HIT getValidationDetails mobile %s address %s",mobile,address));

		return firebaseService.getUpdateDetails(email,userType,mobile,address);
	}

	// ItemDetails API
	 
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/items/{itemType}/getItemDetails/{itemID}")
	public ItemWatch getItemDetails(@PathVariable String itemType,@PathVariable String itemID)throws InterruptedException, ExecutionException {
		logger.log(Level.INFO, String.format("HIT getItemDetails ItemType %s ItemID %s ",itemType,itemID));
		return firebaseService.getWatchDetails(itemID);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/items/watch/postItemDetails")
	public String postItemDetails(@RequestBody ItemWatch itemWatch)throws InterruptedException, ExecutionException{
		//@RequestBody annotation maps the HttpRequest body to an object with Jackson
		//Assign upcoming status to new Item
		itemWatch.setTransactionStatus(Item.transactionStatusPossibility[2]);
		itemWatch.setAuctionStatus(Item.auctionStatusPossibility[2]);
		logger.log(Level.INFO, String.format("HIT postItemDetails ItemType %s ItemID %s ","watch",itemWatch.getItemID()));
		return firebaseService.postItemDetails(itemWatch);

	}
	
	
	 //  ItemList API
	 
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/items/watch/getItemList/{auctionType}")
	public List<ItemWatch> getItemList(@PathVariable String auctionType)throws InterruptedException, ExecutionException {
		logger.log(Level.INFO, String.format("HIT getItemList auctionType %s ",auctionType));
		return firebaseService.getItemList(auctionType);
	}


	 //  History API
	 

	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/getCustomerHistory/{userID}")
	public List<Map<String,Object>> getCustomerHistory(@PathVariable String userID)throws InterruptedException, ExecutionException {
		logger.log(Level.INFO, String.format("HIT getCustomerHistory userID %s ",userID));
		return firebaseService.getCustomerHistory(userID);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/getVendorHistory/{vendorID}")
	public Map<String,List<ItemWatch>> getVendorHistory(@PathVariable String vendorID)throws InterruptedException, ExecutionException {
		logger.log(Level.INFO, String.format("HIT getVendorHistory vendorID %s ",vendorID));
		return firebaseService.getVendorHistory(vendorID);
	}

	
	 // Bid Details API
	 
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/items/watch/getBidDetails/{bidID}")
	public Bid getBidDetails(@PathVariable String bidID)throws InterruptedException, ExecutionException {
		logger.log(Level.INFO, String.format("HIT getBidDetails bidID %s ",bidID));
		return firebaseService.getBidDetails(bidID);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/items/watch/postBidDetails")
	public String postBidDetails(@RequestBody Bid bid)throws InterruptedException, ExecutionException{
		//@RequestBody annotation maps the HttpRequest body to an object with Jackson
		bid.setBidResult(Bid.bidResultPossibility[2]);
		logger.log(Level.INFO, String.format("HIT postBidDetails userID %s itemID %s",bid.getUserID(),bid.getItemID()));
		return firebaseService.postBidDetails(bid);

	}
	
	

	 
	 //  Cleaning API , use deferred for now
	 

	//Function for dealing with oldItems
	@PostMapping("/items/oldItems/watch/postItemDetails")
	public String postItemDetailsPreviousItems(@RequestBody ItemWatch itemWatch)throws InterruptedException, ExecutionException{
		//@RequestBody annotation maps the HttpRequest body to an object with Jackson
		logger.log(Level.INFO, String.format("HIT postItemDetailsPreviousItems ItemType %s ItemID %s ","watch",itemWatch.getItemID()));
		return firebaseService.postItemDetails("oldItems",itemWatch);

	}

	//Function for dealing with oldItems
	@DeleteMapping("/items/{itemType}/deleteItemDetails/{itemID}")
    public String deleteItemDetails(@PathVariable String itemType,@PathVariable String itemID)throws InterruptedException,ExecutionException{
		logger.log(Level.INFO, String.format("HIT deleteItemDetails ItemType %s ItemID %s ",itemType,itemID));
		return firebaseService.deleteItemDetails(itemType,itemID);
    }

}
