export var firebaseConfig = {
  apiKey: "AIzaSyBQDGI2tn82fC3ocaD7Epql25s6FOVli7A",
  authDomain: "eauctionms.firebaseapp.com",
  databaseURL: "https://eauctionms-default-rtdb.firebaseio.com",
  projectId: "eauctionms",
  storageBucket: "eauctionms.appspot.com",
  messagingSenderId: "1057989576612",
  appId: "1:1057989576612:web:8d977deb3a583729516331"
};
