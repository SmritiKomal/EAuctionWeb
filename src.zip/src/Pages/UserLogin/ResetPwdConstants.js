
export const payloadItemWatch={
        "userEmail":"",
        "userAadhar":"",
        "userType":"",
        "userPassword":"",
        "cnfPassword":""
    };