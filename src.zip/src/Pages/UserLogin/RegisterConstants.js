
export const payloadItemWatch={
        "userID":"",
        "userType":"",
        "name":"",
        "age":0,
        "email":"",
        "gender":"",
        "aadhar":"",
        "pan": "",
        "password":"",
        "presentAddress":"",
        "mobile":""
    };
    