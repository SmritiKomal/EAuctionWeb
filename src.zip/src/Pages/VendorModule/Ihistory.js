import React, { Component } from 'react';
import ReactTable from "react-table-6";
import "react-table-6/react-table.css";

class App extends Component {
    render() {
        const data = [{
            ItemName: 'Brass Round Crown',
            st: "ongoing",
            bid: "",
            name:"",
        },{
            ItemName: 'KRUPS Rustic Spice',
            st: "ongoing",
            bid: "",
            name:"",
        },{
            ItemName: 'Hamilton Flex Reach',
            st: "Success",
            bid: "$210",
            name:"Louis",
        },{
            ItemName: 'Empire Gold Dzire',
            st: "upcoming",
            bid: "",
            name:"",
        },{
            ItemName: 'Rustic French Press',
            st: "Success",
            bid: "$200",
            name:"Meghan",
        },{
            ItemName: 'Secura French Press',
            st: "Success",
            bid: "$205",
            name:"Harry",
        }]
        const columns = [{
            Header: 'Item Name',
            accessor: 'ItemName'
        },{
            Header: 'Auction Status              ',
            accessor: 'st'
        },{
            Header: 'Max Bidding             ',
            accessor: 'bid'
        },{
                Header: 'Bidder Name            ',
                accessor: 'name'
            }]

        return (
            <div>
<header><h2>ITEM HISTORY</h2></header>
                <ReactTable
                    data={data}
                    columns={columns}
                    defaultPageSize = {6}
                    pageSizeOptions = {[2,4, 6]}
                />
            </div>
        )
    }
}
export default App;